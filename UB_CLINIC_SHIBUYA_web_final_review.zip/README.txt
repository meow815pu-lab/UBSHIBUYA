UB CLINIC SHIBUYA — Webページ一式

index.html を開くとページを確認できます。
公開する際は index.html と upbeaut-logo-transparent.png を同じフォルダに配置してください。
GitHub Pages等の静的ホスティングで公開できます。
公開前に医療ルール・料金・リンク・文面について院内で最終確認してください。
